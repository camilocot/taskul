==========================
Welcome to Jackrabbit Core
==========================

This is the Core component of the Apache Jackrabbit project.
This component contains the core of the fully JSR-170 compliant
Apache Jackrabbit content repository implementation.
