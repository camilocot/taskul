=========================
Welcome to Jackrabbit API
=========================

This is the API component of the Apache Jackrabbit project.
This component contains the interface extensions that Apache
Jackrabbit supports in addition to the standard JCR API. You can
use these interfaces to access Jackrabbit-specific functionality.
